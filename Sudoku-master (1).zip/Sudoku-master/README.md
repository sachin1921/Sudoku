## [Click here to start application](https://brightsudoku.herokuapp.com/)

### Inputting Numbers<br><br>

<p align="center">
<img src="https://i.gyazo.com/906b4d616df00a12cb06ff45e82f1dc0.gif" style="width: 100px; border: 1px solid black; ">
</p><br>

### Submitting Incorrect Solution<br><br>

<p align="center">
<img src="https://gyazo.com/bac785a17b42de9dfcce9d2bf9f1e955.gif" style="width: 400px; border: 1px solid black; text-align:center;">
</p><br>

### Submitting Correct Solution<br><br>
<p align="center">
<img src="https://gyazo.com/c7ffec457ac32709ee8a4a311500d8a9.gif" style="width: 100px; border: 1px solid black; text-align:center;">
</p>
